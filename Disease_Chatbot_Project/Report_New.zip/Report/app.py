from flask import Flask, request, render_template, jsonify, send_file
import pandas as pd
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

app = Flask(__name__)

# Load data from Excel file
df = pd.read_excel('disease.xlsx')

@app.route('/')
def index():
    return render_template('index1.html')

@app.route('/get_disease', methods=['POST'])
def get_disease():
    name = request.json.get('name')
    disease_name = request.json.get('disease')

    result = df.loc[df['Disease'].str.lower() == disease_name.lower()]

    if not result.empty:
        data = {
            'Name': name,
            'Disease': result.iloc[0]['Disease'],
            'Information': result.iloc[0]['Information'],
            'Symptoms': result.iloc[0]['Symptoms'],
            'Treatment': result.iloc[0]['Treatment'],
            'Precaution': result.iloc[0]['Precaution']
        }
        return jsonify(data)
    else:
        return jsonify({'error': 'Disease not found'}), 404

@app.route('/generate_report', methods=['POST'])
def generate_report():
    name = request.json.get('name')
    disease_name = request.json.get('disease')

    result = df.loc[df['Disease'].str.lower() == disease_name.lower()]

    if not result.empty:
        disease = result.iloc[0]['Disease']
        info = result.iloc[0]['Information']
        symptoms = result.iloc[0]['Symptoms']
        treatment = result.iloc[0]['Treatment']
        precaution = result.iloc[0]['Precaution']

        # Create PDF
        file_path = f'{name}_{disease}_report.pdf'
        c = canvas.Canvas(file_path, pagesize=letter)
        width, height = letter

        # Title
        c.setFont("Helvetica-Bold", 20)
        c.drawString(30, height - 50, f"Medical Report for {name}")

        c.setFont("Helvetica", 16)
        c.drawString(30, height - 90, f"Disease: {disease}")

        # Content
        c.setFont("Helvetica", 14)
        c.drawString(30, height - 130, f"Information: {info}")
        c.drawString(30, height - 180, f"Symptoms: {symptoms}")
        c.drawString(30, height - 230, f"Treatment: {treatment}")
        c.drawString(30, height - 280, f"Precaution: {precaution}")

        c.save()

        return send_file(file_path, as_attachment=True)

    else:
        return jsonify({'error': 'Disease not found'}), 404

if __name__ == '__main__':
    app.run(debug=True)
